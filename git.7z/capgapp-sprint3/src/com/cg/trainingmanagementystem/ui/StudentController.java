package com.cg.trainingmanagementystem.ui;

import java.util.*;

import com.cg.trainingmanagementystem.service.bean.Student;
import com.cg.trainingmanagementystem.service.bean.TrainingProgram;

public class StudentController {

	public StudentController() {
	}

	private Student student;

	private TrainingProgram trainingProgram;

}