package com.cg.trainingmanagementystem.ui;

import com.cg.trainingmanagementystem.service.bean.Course;
import com.cg.trainingmanagementystem.service.bean.Feedback;
import com.cg.trainingmanagementystem.service.bean.Trainer;

/**
 * 
 */
public class AdminController {

	private Trainer trainer;

	private Course course;

	private Feedback feedback;
	
	

}