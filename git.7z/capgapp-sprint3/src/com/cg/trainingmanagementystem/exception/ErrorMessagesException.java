package com.cg.trainingmanagementystem.exception;

public class ErrorMessagesException {

	public static final String MESSAGE1 = "Exception occured while running the program!!!";
	public static final String MESSAGE2 = "Invalid inputs are given";

}
