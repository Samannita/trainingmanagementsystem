package com.cg.trainingmanagementystem.service.impl;

import java.util.*;

import com.cg.trainingmanagementystem.service.ITrainingProgramOperation;
import com.cg.trainingmanagementystem.service.bean.TrainingProgram;

/**
 * 
 */
public class TrainingProgramImpl implements ITrainingProgramOperation {

	@Override
	public boolean createProgram(TrainingProgram trainingProgram) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteTrainingProgram(TrainingProgram trainingProgram) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean modifyTrainingProgram(TrainingProgram trainingProgram) {
		// TODO Auto-generated method stub
		return false;
	}


}