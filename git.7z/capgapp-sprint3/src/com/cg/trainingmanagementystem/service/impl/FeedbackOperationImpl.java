package com.cg.trainingmanagementystem.service.impl;

import java.util.*;

import com.cg.trainingmanagementystem.service.IFeedbackOperation;
import com.cg.trainingmanagementystem.service.bean.Feedback;
import com.cg.trainingmanagementystem.service.bean.TrainingProgram;

/**
 * 
 */
public class FeedbackOperationImpl implements IFeedbackOperation {

	@Override
	public Feedback viewFeedbackReport() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Feedback viewDefaulterList(TrainingProgram trainingProgram, Feedback feedback) {
		// TODO Auto-generated method stub
		return null;
	}

	
}