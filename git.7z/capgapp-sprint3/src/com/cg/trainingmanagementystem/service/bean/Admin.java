package com.cg.trainingmanagementystem.service.bean;

public class Admin extends Employee {

	/**
	 * Default constructor
	 */
	public Admin() {
	}

}