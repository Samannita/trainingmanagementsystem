package com.cg.trainingmanagementystem.service.bean;

import java.util.HashSet;

import com.cg.trainingmanagementystem.service.enumv.Skills;

public class Trainer {

	/**
	 * Default constructor
	 */
	private Trainer() {
	}

	/**
	 * 
	 */
	private String trainerId;

	/**
	 * 
	 */
	private String trainerName;

	/**
	 * 
	 */
	private String TrainerAddress;

	/**
	 * 
	 */
	private HashSet<Skills> skills;




}