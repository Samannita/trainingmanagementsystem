package com.cg.trainingmanagementsystem.dao.impl;

import java.util.Set;

public interface IGetAll<T> {
	public Set<T> retrieveAll();

}
