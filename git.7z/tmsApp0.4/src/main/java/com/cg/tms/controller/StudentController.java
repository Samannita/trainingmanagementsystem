package com.cg.tms.controller;

import java.util.*;

import com.cg.tms.entity.Program;
import com.cg.tms.entity.Student;

public class StudentController {

	public StudentController() {
	}

	private Student student;
	private Program trainingProgram;

}