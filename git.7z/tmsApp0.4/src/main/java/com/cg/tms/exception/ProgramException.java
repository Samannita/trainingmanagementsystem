package com.cg.tms.exception;

public class ProgramException extends Exception {

	private static final long serialVersionUID = 1L;

	public ProgramException(String errorMassage) {
		super(errorMassage);
	}

}
