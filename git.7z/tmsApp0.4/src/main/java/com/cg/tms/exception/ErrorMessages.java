package com.cg.tms.exception;

public class ErrorMessages {
/*Error Messages*/
	public static final String MESSAGE2 = "Some Error Occured while processing";
	public static final String MESSAGE3 = "Some Error Occured While Closing Db";
	public static final String MESSAGE4 = "Some Error Occured while adding the program";
	public static final String MESSAGE5 = "ERROR in closing resourses";
	public static final String MESSAGE6 = "Sorry Training Program not found! Unable to delete";
	public static final String MESSAGE7 = "Course Not Available";
	public static final String MESSAGE8 = "Connection Err with databases";
	public static final String MESSAGE9 = "Program not Available with your input program id";
	public static final String MESSAGE11 = "Some error occured while removing";

}
