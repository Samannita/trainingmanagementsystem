package com.cg.tms.controller;

import com.cg.tms.beans.Trainer;
import com.cg.tms.entity.Course;
import com.cg.tms.entity.Feedback;

/**
 * 
 */
public class AdminController {

	public AdminController() {
	}

	private Trainer trainer;

	private Course course;

	private Feedback feedback;

}