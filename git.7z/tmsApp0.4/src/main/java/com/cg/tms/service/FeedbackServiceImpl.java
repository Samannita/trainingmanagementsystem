package com.cg.tms.service;


import com.cg.tms.entity.Feedback;
import com.cg.tms.entity.Program;

/**
 * 
 */
public class FeedbackServiceImpl implements FeedbackService {

	@Override
	public Feedback viewFeedbackReport() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Feedback viewDefaulterList(Program trainingProgram, Feedback feedback) {
		// TODO Auto-generated method stub
		return null;
	}

	
}