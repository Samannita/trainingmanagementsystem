package com.cg.tms.beans;

import com.cg.tms.entity.Center;
import com.cg.tms.entity.Employee;

public class Coordinator extends Employee {
	private Center center;
	/**
	 * Default constructor
	 */
	public Coordinator() {
	}

	/**
	 * 
	 */
	

}